package com.capgemini.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;



@Controller
public class JspController {

	/*@RequestMapping("/")
    public ModelAndView welcome(){
       ModelAndView modelAndView = new ModelAndView("index");
       return modelAndView;
    }*/
	@RequestMapping("/")
    public ModelAndView first(){
       ModelAndView modelAndView = new ModelAndView("index");
       return modelAndView;
    }
	@RequestMapping("/mens")
    public ModelAndView mensPage(){
       ModelAndView modelAndView = new ModelAndView("mens");
       return modelAndView;
    }
	@RequestMapping("/about")
    public ModelAndView aboutPage(){
       ModelAndView modelAndView = new ModelAndView("about");
       return modelAndView;
    }
	@RequestMapping("/womens")
    public ModelAndView womensPage(){
       ModelAndView modelAndView = new ModelAndView("womens");
       return modelAndView;
    }
	@RequestMapping("/kids")
    public ModelAndView kidsPage(){
       ModelAndView modelAndView = new ModelAndView("kids");
       return modelAndView;
    }
	@RequestMapping("/electronics")
    public ModelAndView electronicsPage(){
       ModelAndView modelAndView = new ModelAndView("electronics");
       return modelAndView;
    }
	@RequestMapping("/customer-homepage")
    public ModelAndView customerPage(){
       ModelAndView modelAndView = new ModelAndView("customer-homepage");
       return modelAndView;
    }
	@RequestMapping("/single")
    public ModelAndView single(){
       ModelAndView modelAndView = new ModelAndView("single");
       return modelAndView;
    }
	@RequestMapping("/cart")
    public ModelAndView cart(){
       ModelAndView modelAndView = new ModelAndView("cart");
       return modelAndView;
    }
	@RequestMapping("/invoice")
    public ModelAndView invoice(){
       ModelAndView modelAndView = new ModelAndView("invoice");
       return modelAndView;
    }
	@RequestMapping("/shipping")
    public ModelAndView shipping(){
       ModelAndView modelAndView = new ModelAndView("shippingDetails");
       return modelAndView;
    }
	@RequestMapping("/changePassword")
    public ModelAndView changePassword(){
       ModelAndView modelAndView = new ModelAndView("changePwd2");
       return modelAndView;
    }
	@RequestMapping("/myOrders")
    public ModelAndView myOrders(){
       ModelAndView modelAndView = new ModelAndView("my-orders");
       return modelAndView;
    }
	@RequestMapping("/coupons")
    public ModelAndView coupons(){
       ModelAndView modelAndView = new ModelAndView("coupons");
       return modelAndView;
    }
}

